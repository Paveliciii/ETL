﻿namespace Shell.UI
{
    using AT.Toolbox;
    using ERMS.Core.Common;
    using ERMS.Core.DAL;
    using ERMS.Core.DbMould;
    using ERMS.UI;
    using GUOP;
    using log4net;
    using Shell.UI.Properties;
    using System;
    using System.IO;
    using System.Windows.Forms;
    using TransportModel;

    internal static class Program
    {
        private static ILog Log;

        [STAThread]
        private static void Main()
        {
            AppInstance.InitializeLogging(Resources.Log4netConfig, null);
            Log = LogManager.GetLogger(typeof(Program).Name);
            string pluginsDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "PlugIns");
            if (!Directory.Exists(pluginsDir))
            {
                Directory.CreateDirectory(pluginsDir);
            }

            foreach (string str in Directory.GetFiles(pluginsDir, "*.dll"))
            {
                string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, Path.GetFileName(str));
                if (File.Exists(path))
                {
                    try
                    {
                        File.Delete(path);
                    }
                    catch (Exception exception)
                    {
                        Log.Error("Main(): Exception ", exception);
                    }
                }
            }
            AppInstance.LoadPlugins = true;
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            AppInstance.ConfigFileFinder = new ConfigFileFinder(new[] { AppDomain.CurrentDomain.BaseDirectory }, "ndtm.config");
            RecordManager.Service = new RecordManagementService();
            FileEntityDescriptionSource.ColumnListSources.Add(new EntityInfoCoulmnListSource(GUOPContext.DataSourceName));
            string fieldDescriptionFile = Shell.UI.Properties.Settings.Default.FieldDescription;
            string fieldDescriptionPath = null;
            try
            {
                if (Path.IsPathRooted(fieldDescriptionFile))
                {
                    fieldDescriptionPath = fieldDescriptionFile;
                }
                else
                {
                    // First, check application base directory (output directory)
                    string baseDir = AppDomain.CurrentDomain.BaseDirectory;
                    string candidate = Path.Combine(baseDir, fieldDescriptionFile);
                    if (File.Exists(candidate))
                        fieldDescriptionPath = candidate;

                    // If not found, walk up a few directory levels to locate the source file (e.g. ../../database.ed when running from bin/Debug)
                    if (fieldDescriptionPath == null)
                    {
                        string up = baseDir;
                        for (int i = 0; i < 6; i++)
                        {
                            up = Path.GetFullPath(Path.Combine(up, ".."));
                            candidate = Path.Combine(up, fieldDescriptionFile);
                            if (File.Exists(candidate))
                            {
                                fieldDescriptionPath = candidate;
                                break;
                            }
                        }
                    }
                }

                if (!string.IsNullOrEmpty(fieldDescriptionPath) && File.Exists(fieldDescriptionPath))
                {
                    try
                    {
                        FileEntityDescriptionSource.Fields[GUOPContext.DataSourceName] = EntityDescriptionContainer.LoadFromFile(fieldDescriptionPath);
                        Log.InfoFormat("Loaded field description from: {0}", fieldDescriptionPath);
                    }
                    catch (Exception ex)
                    {
                        Log.Error("Failed to load field description file", ex);
                    }
                }
                else
                {
                    Log.WarnFormat("Field description file not found: {0}. Continuing without it.", fieldDescriptionFile);
                }
            }
            catch (Exception ex)
            {
                Log.Error("Error while resolving field description file path", ex);
            }
            FormFactory.Customizations[typeof(VisumDatabase)] = new VisumDatabaseFormFactory();
            if (!Directory.Exists(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "PlugIns")))
            {
                Directory.CreateDirectory(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "PlugIns"));
            }
            LookupContainer.Setup<ISqlFormService>(() => new ShellSqlFormService(), true);
            AppWrapper.AddSectionType<ETLSettings>();
            AppWrapper.AddSectionType<ETLShellSettings>();
            AppWrapper.SplashScreen = "Splash.jpg";
            try
            {
                AppWrapper.Run<MainForm>(true);
            }
            catch (Exception ex)
            {
                Log.Error("AppWrapper.Run(requireInit=true) failed; retrying without initialization.", ex);
                try
                {
                    AppWrapper.Run<MainForm>(false);
                }
                catch (Exception inner)
                {
                    Log.Error("AppWrapper.Run(requireInit=false) also failed.", inner);
                    throw;
                }
            }
        }

        public static ETLShellSettings Preferences =>
            AppManager.Configurator.GetSection<ETLShellSettings>();
    }
}

